
        const { SlashCommandBuilder } = require('@discordjs/builders');

        module.exports = {
            data: new SlashCommandBuilder()
                .setName('d')
                .setDescription('d')
        
                .addUserOption(option => option.setName('d').setDescription('Put the wanted d').setRequired(true)),
            
            async execute(interaction, client) {
            
                let user = interaction.options.getUser('d');
                interaction.reply({ content: user.username });
        }
        }