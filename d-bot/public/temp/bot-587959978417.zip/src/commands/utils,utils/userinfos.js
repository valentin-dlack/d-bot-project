
            const { SlashCommandBuilder } = require('@discordjs/builders');

            module.exports = {
                data: new SlashCommandBuilder()
                    .setName('userinfos')
                    .setDescription('get all users infos')
            
                    .addUserOption(option => option.setName('user').setDescription('Put the wanted user').setRequired(false)),
                
                async execute(interaction, client) {
                
                    let user = interaction.options.getUser('user');
                        interaction.reply({ content: 'User infos: ' + user.id + ' ' + user.username + ' ' + user.discriminator + ' ' + user.avatarURL({ format: 'png', dynamic: true, size: 256 }) });
                }
            }