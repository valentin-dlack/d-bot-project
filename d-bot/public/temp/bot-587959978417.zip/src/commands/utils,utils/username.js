
            const { SlashCommandBuilder } = require('@discordjs/builders');

            module.exports = {
                data: new SlashCommandBuilder()
                    .setName('username')
                    .setDescription('Get the user name')
            
                    .addUserOption(option => option.setName('user').setDescription('Put the wanted user').setRequired(true)),
                
                async execute(interaction, client) {
                
                    let user = interaction.options.getUser('user');
                        interaction.reply({ content: user.id });
                }
            }