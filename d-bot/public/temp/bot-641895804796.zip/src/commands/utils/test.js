
        const { SlashCommandBuilder } = require('@discordjs/builders');

        module.exports = {
            data: new SlashCommandBuilder()
                .setName('test')
                .setDescription('test')
        
                .addUserOption(option => option.setName('test').setDescription('Put the wanted test').setRequired(true)),
            
            async execute(interaction, client) {
            
                let user = interaction.options.getUser('test');
                interaction.reply({ content: user.username });
        }
        }