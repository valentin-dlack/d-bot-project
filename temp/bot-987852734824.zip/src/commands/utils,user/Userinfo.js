const { SlashCommandBuilder } = require('@discordjs/builders');

            module.exports = {
                data: new SlashCommandBuilder()
                    .setName('Userinfo')
                    .setDescription('get user info'),
                async execute(interaction) {
                    await interaction.reply('undefined');
                }
            }