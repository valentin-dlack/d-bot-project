
    const { REST } = require('@discordjs/rest');
    const { Routes } = require('discord-api-types/v9');
    const fs = require('fs');
    const config = require('../../config.json');

    const guildId = config.guildId;
    const clientId = config.clientId;

    if (!guildId) console.log('No guildId provided! Please put your guildId in config.json');
    if (!clientId) console.log('No clientId provided! Please put your clientId in config.json');

    module.exports = (client) => {
        client.handleCommands = (commandFolder, path) => {
            client.commandArray = [];
            for (folder of commandFolder) {
                const commands = fs.readdirSync(`${path}/${folder}`).filter(file => file.endsWith('.js'));
                for (file of commands) {
                    const command = require(`../commands/${folder}/${file}`);
                    client.commands.set(command.data.name, command);
                    client.commandArray.push(command.data.toJSON());
                }
            }
            const rest = new REST({ version: '9' }).setToken(config.token);

            (async () => {
                try {
                    console.log('Started registering commands...');

                    await rest.put(
                        Routes.applicationGuildCommands(clientId, guildId), {
                            body: client.commandArray
                        },
                    );

                    console.log('Registered commands!');
                } catch (e) {
                    console.log('Error registering commands! ' + e);
                }
            })();
        }
    }