const { SlashCommandBuilder } = require('@discordjs/builders');

            module.exports = {
                data: new SlashCommandBuilder()
                    .setName('salut')
                    .setDescription('je te dit bonjour'),
                async execute(interaction) {
                    await interaction.reply('yo mon reuf');
                }
            }