
            const { SlashCommandBuilder } = require('@discordjs/builders');

            module.exports = {
                data: new SlashCommandBuilder()
                    .setName('undefined')
                    .setDescription('undefined'),
                async execute(interaction) {
                    await interaction.reply('undefined');
                }
            }
            